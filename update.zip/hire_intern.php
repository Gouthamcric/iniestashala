<?php
session_start();
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INIESTASHALA Internships</title>

 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
   <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>
        <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
        <script src="dist/js/BsMultiSelect.js"></script>


    <link rel="stylesheet" href="internships.css">

    <script src="https://kit.fontawesome.com/18dd5346aa.js" crossorigin="anonymous"></script>
    <style>
       .button1 {
  border-radius: 4px;
  background-color: #bf4d58;;
  border: none;
  color: #FFFFFF;
  text-align: center;
font-size: 17px;
  padding: 10px;
  width: 150px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
  margin-top: -100%;
 height: 55px;
margin-left: 400%;
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 25px;
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}

 
    </style>

</head>

<body>
    <!-- navbar -->
<?php if(!isset($_SESSION['id'])){include('header_2.php');} else {include("header.php");} ?>
 
    <!-- navbar end -->

    <!-- body -->

    <div class="container" style="margin-top: 8%;
">
<h1 style="text-align:center"><u color:black>Hire interns in 3 simple steps</u></h1>
<br>
<br>
        <div class="row" style="margin-left:3%;">
            <div class="col-md-4">
                <img src="images/register.jpeg" style="width: 79%;height: 70%;"><br>
                <h5 style="margin-left: 25%;">1.Register</h5><br>
Get started by creating your account


                                                          
            </div>
             <div class="col-md-4">
                 <img src="images/post.png" style="height: 70%;width: 80%;"><br>
                 <h5 style="margin-left: 40%;">2. Post</h5><br>

                 <p style="margin-left: 23%;">Post internships for any profile and location</p>
            </div>
             <div class="col-md-4">
                 <img src="images/hire.jpeg" style="height: 70%;"><br>
                 <h5 style="margin-left: 40%;">3. Hire</h5><br>
                 <p style="margin-left: 15%;">Screen and hire at your fingertips </p>
            </div>
        </div>
       </div>
       <br>
                <a href="index.php" class="float-left"><button class="button1"><span>Register Now!</span></button></a>  
</body>
</html>
