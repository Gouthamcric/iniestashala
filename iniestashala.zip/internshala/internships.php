<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INIESTASHALA Internships</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <link rel="stylesheet" href="internships.css">

    <script src="https://kit.fontawesome.com/18dd5346aa.js" crossorigin="anonymous"></script>

</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #292b2c;">
        <a class="navbar-brand" style="font-size:x-large;" href="#"><i class="fab fa-invision"></i> INIESTASHALA</a>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a href="index.php" class="nav-link"> 🏚Home</a>
            </li>
        </ul>
    </nav>
    <!-- navbar end -->

    <!-- body -->

    <div class="container-fluid">

        <div class="row">
            <!-- left grid -->
            <div class="col-lg-3 left">
                <!-- <hr class="my-4"> -->
                <div class="card center" style="width: 18rem;">
                    <div class="card-body">
                      <h5 class="card-title">Filter</h5>
                      <hr class="my-4">
                      <!-- <h6 class="card-subtitle mb-2 text-muted">Card subtitle</h6>
                      <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                      <a href="#" class="card-link">Card link</a>
                      <a href="#" class="card-link">Another link</a> -->
                    </div>
                  </div>
            </div>

            <!-- middle grid -->
            <div class="col-lg-6 middle">
                <h4>Internships</h4>
                <div class="card left">
                    <div class="card-header">
                      Web Development
                    </div>
                    <div class="card-body">
                      <h5 class="card-title">Company's name</h5>
                      <p class="card-text">Location : Work from home.</p>
                      <div class="card-text">
                          <div class="card-text">(More information to be added.)</div>
                      </div>

                    </div>
                    <div class="card-footer text-muted">
                      Internship | With job offer  <a href="">Apply ></a>
                    </div>
                  </div>
            </div>

            <!-- right grid -->
            <div class="col-lg-3 right">
                <div class="jumbotron">
                    <h6>Don't miss any opportunity!</h6>
                    <form action="" method="">
                    <input type="text" placeholder="Your email">
                    <a class="btn btn-secondary subscribe-btn" href="#" role="button">Subscribe</a>
                    </form>
                </div>
            </div>
        </div>


    </div>

    <!-- body end -->




    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>
</body>