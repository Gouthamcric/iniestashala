<?php
$con= mysqli_connect("localhost", "root", "", "db")or die(mysqli_errno($con));
